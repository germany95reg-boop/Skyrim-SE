package dev.skyrimsemobile.launcher;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.List;
import java.util.Locale;

/** Read-only BSA metadata and bounded single NIF header probe; never modifies files. */
public final class BsaCatalogActivity extends Activity {
    private static final int PICK_BSA=801;
    private BsaCatalogReader.Catalog catalog;
    private TextView summary,results,inspectionOutput;
    private Uri currentUri;
    private EditText filter;
    private CheckBox nifOnly;
    private String currentName="";
    private volatile boolean destroyed=false;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xff101115);
        getWindow().setNavigationBarColor(0xff101115);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xff101116);scroll.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(14),dp(16),dp(18));scroll.addView(root);
        TextView title=text("Skyrim SE · NIF v1.3",22,0xffdbc5fb);title.setGravity(Gravity.CENTER);root.addView(title);
        root.addView(text("BSA 105: каталог, заголовок NIF и таблица блоков. Выбирай конкретный файл через строку поиска; читаться будет только первая найденная NIF-запись. Без сохранения на диск и изменения игры.",13,0xffd5d3dd));
        button(root,"Выбрать архив BSA",this::pick);
        filter=new EditText(this);filter.setSingleLine(true);filter.setHint("Поиск: meshes, .nif, fish...");
        filter.setTextColor(0xffeeeeee);filter.setHintTextColor(0xffaaa4b8);root.addView(filter);
        nifOnly=new CheckBox(this);nifOnly.setText("Только модели .nif");nifOnly.setTextColor(0xffeeeeee);
        root.addView(nifOnly);
        filter.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int cnt,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){renderResults();}
            public void afterTextChanged(Editable e){}
        });
        nifOnly.setOnCheckedChangeListener((b,value)->renderResults());
        button(root,"Прочитать первый найденный NIF (только заголовок)",this::inspectFirstNif);
        button(root,"Исследовать блоки выбранного NIF · v1.0",this::inspectNifBlocks);
        button(root,"Показать BSTriShape в Vulkan · v1.3",this::previewNifGeometry);
        button(root,"Скопировать список и отчёт",this::copyReport);
        button(root,"Назад",this::finish);
        summary=text("Выбери BSA-файл из памяти телефона. Архив будет открыт только на чтение.",14,0xffeeeeee);
        summary.setTextIsSelectable(true);summary.setPadding(dp(8),dp(10),dp(8),dp(10));
        root.addView(summary);
        results=text("",12,0xffe6e2ed);results.setTextIsSelectable(true);
        results.setPadding(dp(8),dp(10),dp(8),dp(10));root.addView(results);
        inspectionOutput=text("Выбранный NIF ещё не проверялся.",13,0xffd9c1ff);
        inspectionOutput.setTextIsSelectable(true);root.addView(inspectionOutput);
        setContentView(scroll);
    }
    private int dp(float a){return (int)(a*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);t.setPadding(0,dp(9),0,dp(9));return t;}
    private void button(LinearLayout root,String caption,Runnable action){
        Button b=new Button(this);b.setText(caption);b.setAllCaps(false);b.setOnClickListener(v->action.run());root.addView(b);
    }
    private void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i,PICK_BSA);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=PICK_BSA||result!=RESULT_OK||data==null||data.getData()==null)return;
        final Uri uri=data.getData();
        String name="Выбранный BSA";
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())name=c.getString(0);
        }catch(Exception ignored){}
        final String chosen=name;
        summary.setText("Читаю метаданные: "+chosen+"…");results.setText("");catalog=null;currentUri=null;
        inspectionOutput.setText("Выбранный NIF ещё не проверялся.");
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(uri)){
                BsaCatalogReader.Catalog found=BsaCatalogReader.read(in);
                runOnUiThread(()->{if(destroyed)return;currentName=chosen;catalog=found;currentUri=uri;renderResults();});
            }catch(Exception e){
                runOnUiThread(()->{if(destroyed)return;summary.setText("Ошибка чтения каталога: "+e.getMessage());results.setText("Файл не изменён.");});
            }
        },"bsa-v105-catalog").start();
    }
    private void renderResults(){
        if(catalog==null||summary==null||results==null)return;
        BsaCatalogReader.Catalog c=catalog;
        String info="Архив: "+currentName+"\nBSA версия 105; папок: "+c.folderCount+"; файлов: "+c.fileCount+
            "; записей NIF: "+c.nifCount+"\nФлаги: 0x"+Long.toHexString(c.flags)+
            "\nИндекс поиска: "+c.indexedCount+" / "+c.fileCount+
            (c.partialIndex?" (ограничение объёма; поиск неполный)":" (полный)")+
            "\nЧтение только каталога; данные файлов не распакованы и не изменены.";
        summary.setText(info);
        List<BsaCatalogReader.Entry> found=c.find(filter.getText().toString(),nifOnly.isChecked(),60);
        StringBuilder b=new StringBuilder("Совпадения (до 60): "+found.size()+"\n\n");
        for(BsaCatalogReader.Entry entry:found){
            b.append("• ").append(entry.path).append("\n  ")
             .append(entry.storedBytes).append(" байт · 0x")
             .append(Long.toHexString(entry.offset)).append(" · ")
             .append(entry.compressed?"сжат":"без сжатия").append("\n");
        }
        if(found.isEmpty())b.append("В индексированной части архива совпадений нет.");
        results.setText(b.toString());
    }
    private void inspectFirstNif(){
        if(catalog==null || currentUri==null){
            inspectionOutput.setText("Сначала выбери BSA и дождись загрузки каталога.");return;
        }
        List<BsaCatalogReader.Entry> found=catalog.find(filter.getText().toString(),true,1);
        if(found.isEmpty()){
            inspectionOutput.setText("NIF по текущему фильтру не найден. Введи, например, lureargonian01.nif");return;
        }
        BsaCatalogReader.Entry selected=found.get(0);
        final Uri uri=currentUri;
        final long flags=catalog.flags;
        inspectionOutput.setText("Проверяю только одну запись:\n"+selected.path+"\nДанные не сохраняются…");
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(uri)){
                BsaEntryInspector.Result result=BsaEntryInspector.inspect(in,selected,flags);
                runOnUiThread(()->{if(!destroyed && uri.equals(currentUri))inspectionOutput.setText(result.report());});
            }catch(Exception e){
                runOnUiThread(()->{if(!destroyed && uri.equals(currentUri))
                    inspectionOutput.setText("Проверка NIF остановлена: "+e.getMessage()+"\nИсходный архив не изменён.");});
            }
        },"bsa-single-nif-reader").start();
    }
    /** v1.0 reads and validates the NIF block table from only one archive entry. */
    private void inspectNifBlocks(){
        if(catalog==null || currentUri==null){
            inspectionOutput.setText("Сначала выбери BSA и дождись загрузки каталога.");return;
        }
        List<BsaCatalogReader.Entry> found=catalog.find(filter.getText().toString(),true,1);
        if(found.isEmpty()){
            inspectionOutput.setText("NIF не найден. Введи точное имя: lureargonian01.nif");return;
        }
        final BsaCatalogReader.Entry entry=found.get(0);
        final Uri uri=currentUri;
        final long flags=catalog.flags;
        inspectionOutput.setText("Проверяю типы и размеры блоков:\n"+entry.path+"\nВ файл ничего не записывается…");
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(uri)){
                String result=BsaEntryInspector.inspectBlocks(in,entry,flags);
                runOnUiThread(()->{if(!destroyed && uri.equals(currentUri))inspectionOutput.setText(result);});
            }catch(Exception e){
                runOnUiThread(()->{if(!destroyed && uri.equals(currentUri))
                    inspectionOutput.setText("Разбор блоков остановлен: "+e.getMessage()+"\nИсходный BSA не изменён.");});
            }
        },"nif-v10-block-table").start();
    }

    /** v1.1: bounded, read-only NIF extraction and static wireframe preview. */
    private void previewNifGeometry(){
        if(catalog==null||currentUri==null){
            inspectionOutput.setText("Сначала выбери архив BSA.");return;
        }
        List<BsaCatalogReader.Entry> found=catalog.find(filter.getText().toString(),true,1);
        if(found.isEmpty()){
            inspectionOutput.setText("NIF не найден. Введи lureargonian01.nif");return;
        }
        final BsaCatalogReader.Entry entry=found.get(0);
        final Uri uri=currentUri;
        final long flags=catalog.flags;
        inspectionOutput.setText("Декодирую одну модель BSTriShape в памяти: "+entry.path);
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(uri)){
                NifGeometryDecoder.Mesh mesh=BsaEntryInspector.decodeNifGeometry(in,entry,flags);
                runOnUiThread(()->{
                    if(destroyed||!uri.equals(currentUri))return;
                    inspectionOutput.setText("Ресурс: "+entry.path+"\n"+mesh.report());
                    NifGeometryTransfer.offer(mesh.lines,"NIF: "+entry.path.substring(entry.path.lastIndexOf('/')+1),mesh.compactInfo());
                    startActivity(new Intent(this,VulkanSceneActivity.class));
                });
            }catch(Exception e){
                runOnUiThread(()->{if(!destroyed&&uri.equals(currentUri))
                    inspectionOutput.setText("3D-предпросмотр NIF остановлен: "+e.getMessage()+
                        "\nИсходный BSA не изменён. Попробуй другую статическую модель BSTriShape.");});
            }
        },"nif-v13-geometry").start();
    }

    private void copyReport(){
        ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        if(cb!=null)cb.setPrimaryClip(ClipData.newPlainText("Skyrim SE BSA v1.3",summary.getText()+"\n\n"+results.getText()+"\n\n"+inspectionOutput.getText()));
    }
    @Override protected void onDestroy(){destroyed=true;super.onDestroy();}
}
